package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class SongsAdapter(
    private val songs: List<InfoCancion>,
    private val onItemClick: (Int) -> Unit, // Función lambda al hacer clic en la canción
    private val onMoreClick: (Int, View) -> Unit // Función lambda al hacer clic en los 3 puntos
) : RecyclerView.Adapter<SongsAdapter.SongViewHolder>() {

    class SongViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tvSongTitle)
        val tvArtist: TextView = view.findViewById(R.id.tvSongArtist)
        val btnMore: ImageButton = view.findViewById(R.id.btnMore)
        val root: View = view
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_song, parent, false)
        return SongViewHolder(view)
    }

    override fun onBindViewHolder(holder: SongViewHolder, position: Int) {
        val song = songs[position]
        holder.tvTitle.text = song.titulo
        holder.tvArtist.text = song.artista

        // Clic en toda la fila -> Reproducir
        holder.root.setOnClickListener {
            onItemClick(position)
        }

        // Clic en los 3 puntos -> Abrir menú
        holder.btnMore.setOnClickListener { view ->
            onMoreClick(position, view)
        }
    }

    override fun getItemCount() = songs.size
}