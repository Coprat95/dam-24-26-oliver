package com.example.myapplication

import android.media.MediaPlayer
import android.os.Bundle
import android.view.View
import android.media.AudioManager
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.SeekBar
import android.os.Handler
import android.os.Looper
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.graphics.Color
import androidx.constraintlayout.widget.ConstraintLayout
import android.widget.Toast
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import android.os.Build
import android.database.Cursor
import android.provider.OpenableColumns
import android.util.Log

// MODIFICADO: InfoCancion ahora acepta URI o ID
data class InfoCancion(
    val titulo: String,
    val artista: String,
    val audioResId: Int?,
    val audioUri: Uri?,
    val fotoResId: Int
)

class MainActivity : AppCompatActivity() {
    private var reproducirPausar: ImageButton? = null
    private var imagenCancion: ImageView? = null
    private var textoTitulo: TextView? = null
    private var buttonShuffle: ImageButton? = null
    private var buttonRepeat: ImageButton? = null
    private var btnAddSong: ImageButton? = null // NUEVO

    private var isShuffleActive: Boolean = false
    private var isRepeatActive: Boolean = true

    private var seekBar: SeekBar? = null
    private var tiempoActual: TextView? = null
    private var tiempoTotal: TextView? = null
    private var mainLayout: ConstraintLayout? = null

    private var listaCanciones = ArrayList<InfoCancion>()
    private var canciones = ArrayList<MediaPlayer?>()
    private var posicion: Int = 0

    private val handler = Handler(Looper.getMainLooper())
    private val runnable = object : Runnable {
        override fun run() {
            try {
                if (posicion < canciones.size && canciones[posicion] != null && canciones[posicion]!!.isPlaying) {
                    val currentPosition = canciones[posicion]!!.currentPosition
                    seekBar?.progress = currentPosition
                    tiempoActual?.text = formatearTiempo(currentPosition)
                }
            } catch (e: Exception) { e.printStackTrace() }
            handler.postDelayed(this, 1000)
        }
    }

    // --- GESTIÓN DE PERMISOS Y SELECCIÓN DE ARCHIVOS ---

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            if (isGranted) {
                abrirSelectorArchivos()
            } else {
                Toast.makeText(this, "Permiso necesario para añadir canciones", Toast.LENGTH_SHORT).show()
            }
        }

    private val filePickerLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                agregarCancionExterna(uri)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_player)

        volumeControlStream = AudioManager.STREAM_MUSIC

        mainLayout = findViewById(R.id.main)
        imagenCancion = findViewById(R.id.imagenCancion)
        reproducirPausar = findViewById(R.id.buttonPlay)
        textoTitulo = findViewById(R.id.textoTitulo)
        buttonShuffle = findViewById(R.id.buttonShuffle)
        buttonRepeat = findViewById(R.id.buttonRepeat)
        btnAddSong = findViewById(R.id.btnAddSong) // NUEVO

        seekBar = findViewById(R.id.seekBar)
        tiempoActual = findViewById(R.id.tiempoActual)
        tiempoTotal = findViewById(R.id.tiempoTotal)

        mainLayout?.setBackgroundColor(Color.parseColor("#0F1020"))

        // Inicializar canciones base (recursos raw)
        // Notar que pasamos 'null' en audioUri para las canciones internas
        listaCanciones.add(InfoCancion("La Perla", "ROSALÍA", R.raw.rosalia_la_perla, null, R.drawable.foto_rosalia_laperla))
        listaCanciones.add(InfoCancion("Session #2", "DY & BIZA", R.raw.dy_biza_session, null, R.drawable.foto_dy_biza_session))
        listaCanciones.add(InfoCancion("Superestrella", "AITANA", R.raw.aitana_superestrella, null, R.drawable.foto_aitana_superestrella))
        listaCanciones.add(InfoCancion("Tú Vas Sin", "RELS B", R.raw.rels_b_tu_vas_sin, null, R.drawable.foto_relsb_tuvassin))

        // Inicializar la lista de MediaPlayers con nulos
        for (i in listaCanciones.indices) {
            canciones.add(null)
        }

        // Listener para el botón de añadir
        btnAddSong?.setOnClickListener {
            verificarPermisosYabrir()
        }

        // Estilo para el botón añadir (teñirlo de Menta)
        val activeColor = Color.parseColor("#34F5C5")
        btnAddSong?.setColorFilter(activeColor)

        recargarCanciones()
        actualizarUI()
        actualizarEstilosBotones()

        handler.postDelayed(runnable, 0)
    }

    // --- FUNCIONES DE AÑADIR CANCIÓN ---

    private fun verificarPermisosYabrir() {
        // Determinar qué permiso necesitamos según la versión de Android
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            android.Manifest.permission.READ_MEDIA_AUDIO
        } else {
            android.Manifest.permission.READ_EXTERNAL_STORAGE
        }

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            abrirSelectorArchivos()
        } else {
            requestPermissionLauncher.launch(permission)
        }
    }

    private fun abrirSelectorArchivos() {
        // Abre el selector para archivos de audio
        filePickerLauncher.launch("audio/*")
    }

    private fun agregarCancionExterna(uri: Uri) {
        // Obtener nombre del archivo
        val nombreArchivo = obtenerNombreArchivo(uri)

        // Crear nueva info de canción (usamos una imagen genérica o la de la app como carátula)
        val nuevaCancion = InfoCancion(
            titulo = nombreArchivo,
            artista = "Canción Importada",
            audioResId = null, // No es un recurso raw
            audioUri = uri,    // Es una URI externa
            fotoResId = R.drawable.ic_launcher_foreground // Icono por defecto o crea uno 'music_note'
        )

        // Añadir a la lista
        listaCanciones.add(nuevaCancion)
        canciones.add(null) // Añadir hueco en la lista de reproductores

        // Recargar para que el sistema reconozca la nueva canción
        recargarCanciones()

        Toast.makeText(this, "Canción añadida: $nombreArchivo", Toast.LENGTH_LONG).show()
    }

    private fun obtenerNombreArchivo(uri: Uri): String {
        var result: String? = null
        if (uri.scheme == "content") {
            val cursor: Cursor? = contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if(index >= 0) result = it.getString(index)
                }
            }
        }
        if (result == null) {
            result = uri.path
            val cut = result?.lastIndexOf('/')
            if (cut != null && cut != -1) {
                result = result?.substring(cut + 1)
            }
        }
        return result ?: "Canción desconocida"
    }


    // --- CONTROL DE MODOS ---
    fun toggleShuffle(view: View?) {
        if (!isShuffleActive) {
            isShuffleActive = true
            isRepeatActive = false
            Toast.makeText(this, "Aleatorio Activado", Toast.LENGTH_SHORT).show()
        } else {
            isShuffleActive = false
        }
        actualizarEstilosBotones()
    }

    fun toggleRepeat(view: View?) {
        if (!isRepeatActive) {
            isRepeatActive = true
            isShuffleActive = false
            Toast.makeText(this, "Bucle Activado", Toast.LENGTH_SHORT).show()
        } else {
            isRepeatActive = false
        }
        actualizarEstilosBotones()
    }

    private fun actualizarEstilosBotones() {
        val activeColor = Color.parseColor("#34F5C5")
        val inactiveColor = Color.WHITE

        if (isShuffleActive) {
            buttonShuffle?.setColorFilter(activeColor)
            buttonShuffle?.alpha = 1.0f
        } else {
            buttonShuffle?.setColorFilter(inactiveColor)
            buttonShuffle?.alpha = 0.5f
        }

        if (isRepeatActive) {
            buttonRepeat?.setColorFilter(activeColor)
            buttonRepeat?.alpha = 1.0f
        } else {
            buttonRepeat?.setColorFilter(inactiveColor)
            buttonRepeat?.alpha = 0.5f
        }
    }

    fun playPause(view: View?) {
        val mediaPlayer = canciones.getOrNull(posicion)
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying) {
                mediaPlayer.pause()
            } else {
                mediaPlayer.start()
            }
        }
        actualizarUI()
    }

    fun anterior(view: View?) {
        if (posicion < canciones.size && canciones[posicion] != null) canciones[posicion]?.stop()
        recargarCanciones()

        if (posicion == 0) {
            posicion = listaCanciones.size - 1
        } else {
            posicion--
        }

        canciones.getOrNull(posicion)?.start()
        actualizarUI()
    }

    fun siguiente(view: View?) {
        if (posicion < canciones.size && canciones[posicion] != null) canciones[posicion]?.stop()
        recargarCanciones()

        if (isShuffleActive) {
            var newPosition: Int
            do {
                newPosition = (0 until listaCanciones.size).random()
            } while (newPosition == posicion && listaCanciones.size > 1)
            posicion = newPosition
        } else {
            if (posicion < listaCanciones.size - 1) {
                posicion++
            } else {
                if (isRepeatActive) {
                    posicion = 0
                } else {
                    posicion = 0
                    recargarCanciones()
                    actualizarUI()
                    return
                }
            }
        }

        canciones.getOrNull(posicion)?.start()
        actualizarUI()
    }

    private fun recargarCanciones(){
        // Liberar recursos
        for (i in canciones.indices) {
            try {
                if (canciones[i] != null) {
                    canciones[i]?.release()
                    canciones[i] = null
                }
            } catch (e: Exception) { e.printStackTrace() }
        }

        // Recrear instancias
        for (i in listaCanciones.indices) {
            val info = listaCanciones[i]
            try {
                // Lógica dual: Crear desde recurso RAW o desde URI externa
                if (info.audioResId != null) {
                    canciones[i] = MediaPlayer.create(this, info.audioResId)
                } else if (info.audioUri != null) {
                    canciones[i] = MediaPlayer.create(this, info.audioUri)
                }

                if (canciones[i] != null) {
                    canciones[i]?.setOnPreparedListener { mp ->
                        if (i == posicion) {
                            configurarSeekBar(mp)
                        }
                    }
                    canciones[i]?.setOnCompletionListener {
                        siguiente(null)
                    }
                }
            } catch (e: Exception) {
                Log.e("MP3", "Error al cargar canción $i: ${e.message}")
            }
        }
    }

    private fun configurarSeekBar(mediaPlayer: MediaPlayer){
        val duration = mediaPlayer.duration
        seekBar?.max = duration
        tiempoTotal?.text = formatearTiempo(duration)
        seekBar?.progress = 0
        tiempoActual?.text = formatearTiempo(0)

        seekBar?.progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#34F5C5"))
        seekBar?.thumbTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#34F5C5"))

        seekBar?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    mediaPlayer.seekTo(progress)
                    tiempoActual?.text = formatearTiempo(progress)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun actualizarUI(){
        if (listaCanciones.isEmpty()) return

        val cancionActual = listaCanciones[posicion]
        textoTitulo?.text = "${cancionActual.titulo} - ${cancionActual.artista}"

        try {
            imagenCancion?.setImageResource(cancionActual.fotoResId)
        } catch (e: Exception) {}

        if (canciones.getOrNull(posicion)?.isPlaying == true){
            reproducirPausar?.setImageResource(R.drawable.stop)
        } else {
            reproducirPausar?.setImageResource(R.drawable.play)
        }

        actualizarEstilosBotones()

        val mediaPlayer = canciones.getOrNull(posicion)
        if (mediaPlayer != null && mediaPlayer.duration > 0) {
            seekBar?.max = mediaPlayer.duration
            tiempoTotal?.text = formatearTiempo(mediaPlayer.duration)
            seekBar?.progress = mediaPlayer.currentPosition
            tiempoActual?.text = formatearTiempo(mediaPlayer.currentPosition)
        } else {
            seekBar?.max = 1
            seekBar?.progress = 0
            tiempoTotal?.text = "00:00"
            tiempoActual?.text = "00:00"
        }
    }

    private fun formatearTiempo(ms: Int): String {
        val totalSeconds = ms / 1000
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format("%02d:%02d", minutes, seconds)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(runnable)
        for (i in canciones.indices) {
            try {
                canciones[i]?.release()
            } catch (e: Exception) { }
        }
    }
}