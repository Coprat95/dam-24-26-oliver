package com.example.myapplication

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.MenuItem
import android.view.View
import android.widget.ImageButton
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.Serializable
import java.util.ArrayList

// Clase de datos adaptada para manejar tanto recursos internos como archivos externos (Uri)
data class InfoCancion(
    val titulo: String,
    val artista: String,
    val audioResId: Int?, // Recurso R.raw.nombre (para canciones de la app)
    val audioUri: Uri?,    // Uri del archivo externo (para canciones del móvil)
    val fotoResId: Int     // Recurso de carátula por defecto
) : Serializable // Necesario para pasar la lista entre Activities

class AllSongsActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var tvEmpty: TextView
    private lateinit var adapter: SongsAdapter
    // Lista principal de todas las canciones detectadas en el móvil
    private var allSongsList: ArrayList<InfoCancion> = ArrayList()

    // Maneja la solicitud de permisos al usuario
    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            if (isGranted) {
                loadSongs() // Si da permiso, carga las canciones
            } else {
                Toast.makeText(this, "Permiso denegado para leer archivos de audio", Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_all_songs)

        recyclerView = findViewById(R.id.recyclerViewSongs)
        tvEmpty = findViewById(R.id.tvEmpty)
        val btnBack = findViewById<ImageButton>(R.id.btnBack)

        btnBack.setOnClickListener { finish() } // Vuelve a HomeActivity

        // Configurar RecyclerView
        adapter = SongsAdapter(allSongsList,
            onItemClick = { position -> playSong(position) },
            onMoreClick = { position, view -> showPopupMenu(position, view) }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        checkPermissionsAndLoadSongs()
    }

    private fun checkPermissionsAndLoadSongs() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            android.Manifest.permission.READ_MEDIA_AUDIO
        } else {
            android.Manifest.permission.READ_EXTERNAL_STORAGE
        }

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            loadSongs()
        } else {
            requestPermissionLauncher.launch(permission)
        }
    }

    private fun loadSongs() {
        allSongsList.clear()
        // Proyección: Columnas que necesitamos
        val projection = arrayOf(
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DATA, // Ruta de archivo
            MediaStore.Audio.Media._ID
        )

        // Excluir archivos que no son música y son pequeños
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"

        val cursor = contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            null,
            null
        )

        cursor?.use {
            val titleColumn = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistColumn = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val dataColumn = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)

            while (it.moveToNext()) {
                val title = it.getString(titleColumn)
                val artist = it.getString(artistColumn) ?: "Artista Desconocido"
                val path = it.getString(dataColumn)

                val songUri = Uri.parse("file://$path")

                // Añadir canción como archivo externo (Uri)
                allSongsList.add(InfoCancion(
                    titulo = title,
                    artista = artist,
                    audioResId = null,
                    audioUri = songUri,
                    fotoResId = R.drawable.ic_launcher_foreground // Icono por defecto
                ))
            }
        }

        if (allSongsList.isEmpty()) {
            tvEmpty.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
        } else {
            tvEmpty.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
        }
        adapter.notifyDataSetChanged()
    }

    // Abre el reproductor (MainActivity) con la canción seleccionada
    private fun playSong(position: Int) {
        val intent = Intent(this, MainActivity::class.java).apply {
            // Pasamos la lista completa y la posición inicial
            putExtra("SONG_LIST", allSongsList as java.io.Serializable)
            putExtra("START_POSITION", position)
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        startActivity(intent)
    }

    // Muestra el menú de 3 puntos
    private fun showPopupMenu(position: Int, view: View) {
        val popup = PopupMenu(this, view)
        popup.menuInflater.inflate(R.menu.song_options, popup.menu)

        // Aquí iría la lógica de las opciones del menú
        popup.setOnMenuItemClickListener { item: MenuItem ->
            when (item.itemId) {
                R.id.action_play_next -> {
                    Toast.makeText(this, "Reproducir Siguiente (Pendiente)", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.action_add_to_playlist -> {
                    Toast.makeText(this, "Añadir a Playlist (Pendiente)", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.action_delete -> {
                    Toast.makeText(this, "Eliminar (Pendiente)", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }
        popup.show()
    }
}