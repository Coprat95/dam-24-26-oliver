package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Vinculamos las vistas usando los IDs que ahora SÍ existen en el XML
        val cardAllSongs = findViewById<CardView>(R.id.cardAllSongs)
        val cardPlaylists = findViewById<CardView>(R.id.cardPlaylists)
        val fabCreatePlaylist = findViewById<ImageButton>(R.id.fabCreatePlaylist)

        // NAVEGACIÓN: Ir a la lista de canciones
        cardAllSongs.setOnClickListener {
            val intent = Intent(this, AllSongsActivity::class.java)
            startActivity(intent)
        }

        // BOTÓN DE PLAYLISTS (Futura implementación)
        cardPlaylists.setOnClickListener {
            Toast.makeText(this, "Mis Playlists: Próximamente", Toast.LENGTH_SHORT).show()
        }

        // BOTÓN DE CREAR (Futura implementación)
        fabCreatePlaylist.setOnClickListener {
            Toast.makeText(this, "Crear Playlist: Próximamente", Toast.LENGTH_SHORT).show()
        }
    }
}